# Changelog

## 1.0.0
- Initial release: the morning message says "Dawn" instead of "Day N".

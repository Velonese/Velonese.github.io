# EternalValheim

Time without number.

## Features

- At sunrise the game shows "Day 365" (or whatever day it is) in the middle of everyone's screen. This mod shows "Dawn"
  instead.
- Nothing else changes: the day count still runs in the background, and the morning music still plays.

## Multiplayer

The message is drawn on each player's own screen, so each player needs the mod to see "Dawn". A player without it still
sees the day number. The server does not need it.

# Changelog

## 1.0.0
- Initial release: wood and stone portals each have their own settings for whether they can be built, extra build cost, and their portal style (`Default` or `Fueled`, with fuel modes `UsesPerFuel`, `TimePerFuel` or `UntilSunriseOrSunset` and a configurable fuel item), and customizable fuel text. Server-synced settings.

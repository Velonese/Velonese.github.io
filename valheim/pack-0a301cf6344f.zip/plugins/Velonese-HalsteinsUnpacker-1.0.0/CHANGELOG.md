# Changelog

## 1.0.0
- Initial release: servers offer a modpack (a manifest plus one zip) over https. Joining players download it when
  they are missing or behind on plugins or configs, then restart and rejoin. Plugins are only ever upgraded.

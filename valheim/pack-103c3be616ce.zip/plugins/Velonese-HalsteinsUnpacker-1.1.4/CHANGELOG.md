# Changelog

## 1.1.4
- The update dialog now summarises the changes ("2 new mods and 5 updated mods") instead of listing every file, which Valheim shrank to unreadable.

## 1.1.3
- Players now check the pack before connecting. When you join a server whose pack you've already trusted, HalsteinsUnpacker compares your mods with the pack first and offers the update at the main menu, instead of after connecting. Mods that check versions during the connection (Jötunn, ConditionalConfigSync...) no longer reject an out-of-date client before it can update. If the pack can't be reached the join goes ahead as before, and the first time you join a server is unchanged. Players need to install this version by hand once.

## 1.1.2
- Servers with Jötunn no longer kick a player for a Jötunn (or Jötunn mod) version mismatch before they can be offered the modpack. The player is offered the pack, and is disconnected unless they are updating. Needs a server restart; players don't need anything.

## 1.1.0
- Removed the automatic restart. After downloading, HalsteinsUnpacker now tells you to restart Valheim yourself and rejoin the server. The `AutoRestart` setting no longer exists.

## 1.0.5
- Fixed a loop where the client kept asking for the same config files after every restart, ending in an "incompatible version" kick. Configs the pack already installed are no longer re-downloaded just because a mod rewrote them.

## 1.0.4
- Fixed the server rejecting a good modpack manifest ("it has no archive"): the manifest is now read with a more reliable JSON reader.

## 1.0.3
- The modpack manifest types are now public.

## 1.0.2
- The log now shows what the server received when a modpack manifest has no archive, to help find why.

## 1.0.1
- Fixed the modpack offer not reaching every joining player reliably, and players being offered the pack more than once.

## 1.0.0
- Initial release: servers offer a modpack (a manifest plus one zip) over https. Joining players download it when
  they are missing or behind on plugins or configs, then restart and rejoin. Plugins are only ever upgraded.

# Changelog

## 1.0.0
- Initial release: creature hits on players, tames and buildings inside a shield dome drain the shield's fuel instead.

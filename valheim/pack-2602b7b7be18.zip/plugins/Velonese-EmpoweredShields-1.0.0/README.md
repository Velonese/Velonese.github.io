# EmpoweredShields

A shield generator's dome protects what is inside it from melee too, not just from ranged attacks.

## Features

- When a creature hits a player, a tame or a building that is inside a shield dome, the hit does no damage. It drains the
  shield's fuel instead, at the same rate as a projectile hitting the dome, and plays the shield-hit effect.
- Only the target's position counts. A creature that has walked inside the dome is blocked the same as one outside it.
- Once the fuel runs out the dome drops and hits land normally again.
- Hits from players, tames, fire, lava and other non-creature sources are not touched. Wild creatures inside the dome take
  damage normally.

## Multiplayer

The check runs on the game of whoever owns the target: each player for their own character, and the area owner for buildings
and tames. Every player needs the mod, and the server should have it too.

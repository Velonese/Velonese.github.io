# Changelog

## 1.0.2
- PlantEverything: middle-click removal of its flora pieces now works with the Enchanted Cultivator.

## 1.0.1
- Fixed the Enchanted Cultivator not being recognised: Plant Easily grid planting now works with it, and its plants grow in any biome.
- No longer logs harmless warnings from the main menu.

## 1.0.0
- Initial release: adds the Enchanted Cultivator.

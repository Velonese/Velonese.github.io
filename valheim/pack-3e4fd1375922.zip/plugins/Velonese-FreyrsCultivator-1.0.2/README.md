# Freyr's Cultivator

A new cultivator for Valheim.

## Features

- Adds the Enchanted Cultivator, crafted at the galdr table from 10 Yggdrasil wood, 10 silver and 10 eitr.
- It has 400 durability and can be upgraded twice at the galdr table, to 600 and then 800.
  The first upgrade costs 2 Yggdrasil wood and 5 silver, the second 4 Yggdrasil wood and 10 silver.
- It plants everything the standard cultivator can, and anything planted with it grows in every biome: carrots,
  turnips and onions in the Mountains, barley and flax in the Meadows, Jotun puffs and magecap outside the Mistlands,
  and so on. Crops still need cultivated ground. Plants placed with the standard cultivator keep the usual biome rules.

## Compatibility

- **Plant Easily**: grid planting works with the Enchanted Cultivator, and every plant in the grid can grow in any biome.
- **PlantEverything**: middle click removes its flora pieces (stones, dandelions, mushrooms and so on) with the Enchanted Cultivator, as with the standard one.

## Configuration

`BepInEx/config/velonese.freyrscultivator.cfg`, or press F1 in game with BepInEx ConfigurationManager installed.

## Multiplayer

Every player needs the mod. Plants are grown by whichever player is nearest, and a player without the
mod would see an Enchanted Cultivator plant as being in the wrong biome, so it would not grow.

# LeashMe Valheim Mod

**Lead them, hitch them, load your lox.**

LeashMe adds an upgradeable leash, a pack saddle for lox, hitching posts in 3 levels and map markers for tamed animals. Leashed animals follow you even through water and portals (big animals need stone portals). The pack saddle turns a lox into a personal chest with 24 slots (no riding). Tied to a post, animals still eat and breed while you are nearby. Works on all tameable animals except creatures summoned by the spirit caller staff.

## Features at a glance

* **The leash:** three upgrade levels, off-hand, no durability.
* **Leading animals:** up to 5 animals, visible rope, distance limits, animals do not fight.
* **Portals:** take leashed animals through portals. Lox, asksvin and moose only fit through stone portals.
* **Pack saddle:** lox inventory with visible cargo and persistent storage.
* **Hitching post (new in 1.3.0):** tie up to 5 animals so they stay put while you are away. While you are nearby, they eat and breed like vanilla.
* **Map markers:** automatic and manual paw markers.
* **Nursery (separate mod):** the Nursery Beacon gathers your tamed young animals of one species in one place. Works with or without LeashMe. Download: [Nexus](https://www.nexusmods.com/valheim/mods/4471), [Hexium](https://valheim.hexium.gg/mods/evabs/LeashMe_Nursery), [Thunderstore](https://thunderstore.io/c/valheim/p/evabs/LeashMe_Nursery/)

> **Leashed animals do not fight!** A leashed animal ignores enemies completely, even when it is attacked, and it can die - enemies still attack it. Before a fight, unleash your animals (press **Use** on them or put the leash away) so they can defend themselves.

## Quick start

1. Craft the leash at a workbench (level 3) from 10 leather scraps.
2. Equip it in your off-hand.
3. Look at a tamed animal and press **Use** (**Leash**). Repeat for up to 5 animals.
4. Walk. The animals follow.
5. Press **Use** on an animal again (**Unleash**) to let it stay.

**Version:** 1.3.8

**Languages:** English and German.

**Mod pages:** [Nexus](https://www.nexusmods.com/valheim/mods/4107), [Hexium](https://valheim.hexium.gg/mods/evabs/LeashMe), [Thunderstore](https://thunderstore.io/c/valheim/p/evabs/LeashMe/)

## Requirements

* BepInExPack for Valheim: [Nexus](https://www.nexusmods.com/valheim/mods/3605), [Hexium](https://valheim.hexium.gg/mods/denikson/BepInExPack_Valheim), [Thunderstore](https://thunderstore.io/c/valheim/p/denikson/BepInExPack_Valheim/)
* Jotunn, the Valheim Library: [Nexus](https://www.nexusmods.com/valheim/mods/1138), [Hexium](https://valheim.hexium.gg/mods/ValheimModding/Jotunn), [Thunderstore](https://thunderstore.io/c/valheim/p/ValheimModding/Jotunn/)

Tested with Valheim 1.0.20, BepInExPack 5.4.2351 and Jotunn 2.30.2.

## Installation instructions

**Vortex / mod manager:** install LeashMe and its requirements.

**Manual:**

1. Install BepInExPack for Valheim
2. Install Jotunn
3. Copy `LeashMe.dll` into `<Valheim>/BepInEx/plugins`.
4. Start the game.

For a dedicated server, install the same way into the server's `BepInEx/plugins` folder.

**Multiplayer:** every player and the server need LeashMe (same minor version). Players without it, or with a different version, are rejected on connect with an error message (Jotunn).

**Uninstalling:** remove `LeashMe.dll`. Before that, best empty your pack saddles and take them off.

* Leashes and pack saddles in inventories and chests disappear.
* Hitching posts, cargo crates (with their contents) and pack saddles lying on the ground disappear and are usually deleted for good, so reinstalling does not bring them back. Building materials are not returned.
* A pack saddle on a lox becomes invisible and cannot be opened; the lox is a normal lox again. Its cargo stays saved on the lox and is back when you reinstall LeashMe, but it is lost if the lox dies in the meantime.
* A leash or pack saddle on an item stand becomes invisible. It is back when you reinstall, unless someone takes it off the stand in the meantime (then it is lost).
* Tied animals stay where their post was, like animals told to stay.
* Paw markers you placed yourself become standard markers (see Map markers).

## Main features

### The leash

Crafted at the workbench and upgraded there like any vanilla item. Stronger animals need a stronger leash:

* **Level 1** (craft, workbench level 3): 10 leather scraps. Boar, hen.
* **Level 2** (upgrade, workbench level 4): 5 leather scraps, 5 fenris hair. Also wolf.
* **Level 3** (upgrade, workbench level 5): 5 leather scraps, 5 linen thread. Also lox, asksvin, moose, and all other tamed animals.

If your leash is too weak, the animal shows *This animal needs a stronger leash* when you look at it with your leash equipped. Unknown tameable animals (for example from other mods) need level 3.

* No durability.
* Equipped in the shield / off-hand slot, shown as a rope wrapped around your left hand. It does not block or parry. You can use one-handed items in your main hand while using the leash. Equipping two-handed items or putting your weapons away will unleash all animals.
* Can be hung on item stands (coiled on a horizontal stand, hanging on a wall stand), but not on armor stands.

### Leading animals

* A visible rope runs from your hand to each animal's head, with slight sag when close.
* From 12 m you cannot walk further away from a leashed animal (no pulling the animals, but walking towards it or sideways still works).
* Leashed animals start running much earlier than in vanilla (a few metres behind you instead of 10 m), so they stay close when you run, e.g. around corners in your base.
* Beyond 18 m (lox: 30 m) (e.g. the animal is stuck or being moved away from you) the animal is released and you get a message. Lox get a longer leash because they often need a detour in tight spots.
* A leashed animal ignores enemies. It neither attacks nor flees, not even when it is hit, and keeps following you. Quickly unleash your animals with the **Hide** key (put hand items away) if you want them to flee or fight.
* **Careful with lox in tight spaces** (houses, narrow paths, between buildings): vanilla pathfinding often finds no way for such a big animal. The lox then seems to run off in another direction while it searches for a detour to you. Lead lox through open terrain where possible.

The leash ends automatically and the animals stay in place when:

* you unequip the leash, drop it or equip a shield, two-handed weapon or tool (e.g. building hammer) in its place
* you put your hand items away manually (**Hide**)
* you or the animal die, or you log out / disconnect
* the animal is more than 18 m (lox: 30 m) away (only this animal)

Swimming, crafting at a station or the barber hide your hand items only temporarily: the leash stays active and you take it back in hand afterwards. Sitting and steering a ship keep the leash in your hand.

### Portals

Leashed animals travel through portals with you and appear in front of you at the exit.

* Stone portal: all tamed animals
* Wooden portal: all tamed animals except lox, asksvin and moose, they are too big. If one of your leashed animals does not fit, the portal does not activate and you get a message. Your animals stay leashed.
* Animals are not affected by the item teleport restrictions (metals etc.).
* Dungeon entrances and non-portal teleports do not take animals along, and if you enter, the leash will be released with a message.

### Pack saddle

A saddle for lox with its own inventory. It turns the lox into a pack animal. You cannot ride on it - lead the lox on the leash instead.

* Crafted at the same station and level as the vanilla lox saddle: 10 black metal, 20 leather scraps, 10 linen thread, 20 wood. Cannot be upgraded.
* **Put it on** like the vanilla saddle: put it in your hotbar, look at a tamed lox and press its number key. Only lox, and only one saddle per lox (pack saddle or vanilla saddle).
* **Look at the pack saddle:** **Use** opens the inventory, **Shift + Use** takes the saddle off (only when the inventory is empty). Both work with or without the leash in your hand.
* **Personal:** only the player who put the saddle on can open it and take it off. For everyone else it behaves like the lox itself. Wards do not lock it.
* Same size as a reinforced chest. The content stays on the lox, also after logout and server restart.
* The load shows on the lox: the two upper crates are always there, the bedroll appears with the first item, a lower crate on the left once more than half of the slots are used and one on the right above three quarters. They disappear again as you unload.
* The cargo does not slow the lox down.
* **If the lox dies,** all cargo drops in floating cargo crates (like a sinking ship) and the pack saddle falls next to them. Anyone can empty the crates; they disappear when empty.
* Can be put on a horizontal item stand, not on wall stands or armor stands.

### Hitching post

A post to tie up leashed animals. They stay tied while you are away, also after logout and server restart.

* Built with the hammer, workbench nearby, on the ground or on stone, not on wood (like a fireplace). About 1.5 m high: a carved core wood post with a cleat on top (core wood, silver or black metal). Three versions, like the leash levels:

  * **Weak Hitching Post:** 3 core wood. Boar, hen.
  * **Hitching Post:** 3 core wood, 10 silver. Also wolf.
  * **Strong Hitching Post:** 3 core wood, 20 black metal. All tamed animals.
* **Tie up:** with the leash in your hand, look at the post and press **Use**. All your leashed animals that fit move from the leash to the post, up to 5 per post. Animals that do not fit (post too weak, animal too far away, no room) stay on your leash and you get a message. Tied animals no longer count for your leash limit.
* **Untie all:** with the leash in your hand, **Shift + Use** on the post takes all its animals onto your leash (up to 5, leash level permitting). **Use** on a tied animal takes only this animal. Any player can untie animals.
* While animals are tied, a leather strap is wrapped around the post's cleat.
* A tied animal stays close to the post with a visible rope. Like on the leash, it does not fight or flee. It cannot be switched to follow/stay or ridden. Petting, taking off a saddle and the pack saddle still work.
* Tied animals eat and breed like vanilla, so only while the area is loaded (you or another player nearby). Hungry animals walk to food near them (up to 10 m) and then return to the post, so put the food close to the post. Offspring is not tied. Careful: a trail of food leading more than 18 m away from the post can lure an animal far enough to release it.
* Health: 1000 / 2000 / 4000 (a vanilla core wood pole has about 500). The stronger posts are sturdier, so big animals like lox do not break them as quickly.
* If the post is removed or destroyed, its animals stay where they are. They are also released if they get more than 18 m away from the post.

### Map markers

* **Paw markers:** all tamed animals in your currently loaded area are marked on the map and minimap, no matter who tamed them, so you can find your Hen in the forest again. These markers are not saved and they move with the animals. You can turn them off by right-clicking the paw icon in the bottom right of the large map.
* **Groups:** three or more nearby animals of the same species share one paw at their centre, labelled for example **5 Wolves** on the large map. The minimap shows only the paw. Adults and young have separate groups when each has at least three animals; smaller age cohorts join a mixed group. One or two animals keep their individual markers and names. New groups require every pair to be within 15 m horizontally; existing members can move up to 20 m apart before splitting. Groups update about once a second, independently of zoom. For mod animals, young are matched only through unambiguous growth-prefab references; unknown species names keep their own localized wording.
* **Your own paw markers:** the paw is available as a marker like the vanilla markers. Select it and double-click the map to place one (it will be saved, can be named and removed like vanilla markers). Right-click the paw in the marker bar to show/hide all manual and automatic paw markers.
* Paw map markers you place yourself are saved with the character's map. If the character is loaded without LeashMe, Valheim shows them as a standard marker (name and position are kept). Once saved without LeashMe, they stay standard markers, also after reinstalling the mod. The same applies to markers shared via a cartography table.

### Vanilla interactions

While you hold the leash, tamed animals show only **Leash** / **Unleash** instead of the vanilla actions (pet, follow/stay, ride). To use those, unequip the leash first. Exceptions: the pack saddle actions (open, take off) and taking off a vanilla saddle (**Shift + Use** on the saddle) also work with the leash. Without the leash equipped, LeashMe does not change any animal interaction.

A leashed animal cannot be switched between follow/stay by anyone, including its holder - it always follows.

## Multiplayer

* Other players can see your leash. They cannot take over or command an animal you are leading. They can still pet it of course. As in vanilla, tamed animals are not owned by the player who tamed them. Another player can therefore leash any tamed animal that is not already leashed or following another player.
* When an animal is ridden by a player, it CAN be leashed by another player. While the rider gives commands like direction, the leash does not have any effect as the rider commands override the leash commands. If the rider does not give any commands, the animal can be led around by the leash with the rider on top. If the rider steers the animal more than 18 m (lox: 30 m) away, the animal will be auto-unleashed with a message to the player holding the leash.

## Known issues

* Vanilla behaviour from item stands affects this mod: if you put an equipped leash (or any shield) on an item stand and take it back, the inventory still marks it as equipped although it is not in your hand, so you cannot leash animals. Unequip and equip it again.
* As mentioned above, Lox and especially 5 of them on a leash are very difficult to control because of pathfinding issues in narrow spaces (between a house and a wall, on bridges, etc.) where they cannot mow down tiny things like fully grown trees and such. They turn around to pathfind a lot which can be super annoying. If you plan on keeping them at your base, make sure you have a wide entrance to their enclosure.
* **Not compatible with** [**LoxSaddleBags**](https://thunderstore.io/c/valheim/p/Moddermother/LoxSaddleBags/)**:** its saddle can be put on a lox that already wears a pack saddle.

## Compatibility

I am a software developer and I have 1000+ hours in Valheim. I love this game. I do use some mods which were all active when I developed and tested this mod:

* Willybachs HD Valheim and Badgers HD Terrain <3
* Advize Plant Everything
* CraftFromContainers
* CraftingStationTweakz
* ExtendedPlayerInventory
* FloatingItems
* PlanBuild
* QuickStackStore
* Sakey's My Kvastur
* ValheimBuildCamera

The pack saddle, cargo crates and hitching posts use the game's own materials for wood, metal and linen, so texture mods like Willybachs HD Valheim apply to them too. Only the leash keeps its own leather texture.

**XPortal:** leashed animals travel with you through portals with XPortal destinations.

## Changelog

* **1.3.8** – Performance: improvements for attaching LeashMe models to wild creatures and the rope check. For other players, the rope of a freshly tamed creature may appear up to a second later, the attaching player sees it right away. Works together with 1.3.7.
* **1.3.7** – Performance: hitching posts check their leather wrap once per second instead of every frame; for other players the wrap may appear or disappear up to a second later, the attaching player sees it right away. Works together with 1.3.6.
* **1.3.6** – Descriptions: link to the new separate mod LeashMe Nursery, XPortal in the compatibility notes. No gameplay changes; works together with 1.3.5.
* **1.3.5** – New mod icon.
* **1.3.4** – Map: three or more nearby tamed animals of the same species share one paw marker, labelled with count and name on the large map (for example **5 Wolves**). New inventory and build menu icons made from the actual leash, pack saddle and hitching post models. Works together with 1.3.0 to 1.3.3; paw markers are only shown on your own map, so players can update independently.
* **1.3.3** – Smoother shading on the hitching posts, pack saddle, cargo crates and leash. No gameplay changes; works together with 1.3.0 to 1.3.2. Uninstall notes now explain what happens to pack saddles and hitching posts.
* **1.3.2** – Leashed animals start running much earlier, so they stay close behind you instead of falling back and stopping you at 12 m. Works together with 1.3.0 and 1.3.1; animals behave the new way when their game is run by a player with 1.3.2, so all players should update.
* **1.3.1** – Updated descriptions. No gameplay changes; works together with 1.3.0.
* **1.3.0** – New: hitching post in three levels (core wood, silver, black metal) to tie up to 5 animals, with a leather strap on the cleat while animals are tied. Pack saddle: size of a reinforced chest (was wooden chest), reworked bedroll, new inventory icon. Pack saddle, cargo crates and hitching posts now use the game's own materials (cart wood, linen, silver, black metal), so they match the vanilla look and texture mods apply to them; no snow on the moving lox's saddle. Leash: hangs as a coil on wall item stands, loop to the front on horizontal stands, slightly darker leather. All players and the server need the new version.
* **1.2.0** – New: pack saddle for lox (own inventory, visible cargo, cargo crates on death). Moose: leash level 3, too big for the wooden portal, rope at the head. Spirit caller summons are no longer leashable and get no paw marker. Paw marker slightly darker. All players and the server need the new version.
* **1.1.0** – Lox are released at 30 m instead of 18 m, so they have room for pathfinding detours. Fixed: an animal that was hit while leashed now fights back right after you unleash it. All players and the server need the new version.
* **1.0.0** – First release.




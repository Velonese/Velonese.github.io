# Changelog

## 1.2.0
- New fuel modes `UntilSunset` and `UntilSunrise`: a refill keeps the portal active until the next sunset, or the next sunrise, only, so it can last up to a full day or night. New text settings `RefillSunset` and `RefillSunrise`.

## 1.1.0
- Settings now sync with ServerSync. While you're connected, Configuration Manager shows the server's values, and admins can change them in-game: the server saves the change to its config file and sends it to everyone. Other players can't change the synced settings. Editing the server's config file while it runs still works as before.
- Players with mismatched BuyfrostGates versions are no longer switched back to their own settings; they get every setting their version knows about from the server, with a warning in the log.

## 1.0.1
- Fixed settings not syncing reliably when joining a server. Clients now also ask the server for settings after connecting, and go back to local settings when they leave.

## 1.0.0
- Initial release: wood and stone portals each have their own settings for whether they can be built, extra build cost, and their portal style (`Default` or `Fueled`, with fuel modes `UsesPerFuel`, `TimePerFuel` or `UntilSunriseOrSunset` and a configurable fuel item), and customizable fuel text. Server-synced settings.

# Changelog

## 1.0.1
- The message is now "Dawn has arrived", and can be changed with the `Message` setting. The setting syncs from the server, and admins can change it in-game with Configuration Manager.

## 1.0.0
- Initial release: the morning message says "Dawn" instead of "Day N".

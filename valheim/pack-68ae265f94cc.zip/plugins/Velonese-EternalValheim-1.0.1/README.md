# EternalValheim

Time without number.

## Features

- At sunrise the game shows "Day 365" (or whatever day it is) in the middle of everyone's screen. This mod shows "Dawn
  has arrived" instead, or any text you set.
- Nothing else changes: the day count still runs in the background, and the morning music still plays.

## Configuration

`BepInEx/config/velonese.eternalvalheim.cfg`, or press F1 in game with BepInEx ConfigurationManager installed.

The setting syncs from the server with ServerSync. While you're connected, the server's value is used, and admins can change it
in-game: the server saves the change and sends it to everyone straight away.

| Setting | Description |
|---|---|
| `Message` | Text shown at sunrise. Default: `Dawn has arrived`. |

## Multiplayer

The message is drawn on each player's own screen, so each player needs the mod to see it. A player without it still
sees the day number. The server needs it too, to share the message with everyone.

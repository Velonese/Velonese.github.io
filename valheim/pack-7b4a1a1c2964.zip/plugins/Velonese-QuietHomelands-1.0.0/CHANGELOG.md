# Changelog

## 1.0.0
- Initial release: removes the Meadows, Black Forest and Mountain world spawns that unlock after Yagluth, the Queen and Fader.

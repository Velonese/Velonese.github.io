# QuietHomelands

Keep the early biomes quiet after the late bosses fall.

## Features

- Killing Yagluth, the Queen or Fader unlocks extra night spawns in the Meadows, Black Forest and Mountains (Fulings, Seekers,
  Charred). This mod removes those spawns from those biomes.
- The boss keys themselves are left alone, so trader stock (Haldor, the Bog Witch), raids, dreams and anything else tied to
  them still work.
- Spawns in the creatures' home biomes are not touched.
- When the world loads, the BepInEx log gets one line listing every spawn the mod changed.

## Configuration

`BepInEx/config/velonese.quiethomelands.cfg`

| Setting | Description |
|---|---|
| `Keys` | World keys whose spawns are removed. Default: `defeated_goblinking,defeated_queen,defeated_fader`. |
| `Biomes` | Biomes the spawns are removed from. Default: `Meadows,BlackForest,Mountain`. |

## Multiplayer

World spawns run on the game of whichever player owns the area, never on a dedicated server, so every player needs the mod. A
player without it still gets these spawns around them. The server does not need it.

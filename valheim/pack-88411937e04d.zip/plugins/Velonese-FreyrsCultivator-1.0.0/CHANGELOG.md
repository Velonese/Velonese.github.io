# Changelog

## 1.0.0
- Initial release: adds the Enchanted Cultivator.

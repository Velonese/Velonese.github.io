# 1.0.8
* added whole-mod hidden policy support: a bare mod GUID in `ConditionalConfigSync.HiddenConfigs.cfg` now hides all settings registered by that mod
* kept whole-mod identifiers exclusive to hidden policy; `SyncPolicy.cfg` still accepts only section and exact-setting targets

# 1.0.7
* resent version handshakes immediately before vanilla `PeerInfo`, reducing false `HandshakeMissing` rejections after transient PlayFab or other transport recovery during connection setup

# 1.0.6
* added `ModRequirementMode.Fixed` and `ModRequirementMode.Conditional`; existing consumers remain fixed by default and keep their previous `ModRequired` behavior without recompilation
* added server-only `ConditionalConfigSync.ModRequirements.cfg` admission policy, where `+ ModGuid` requires a Conditional consumer and `- ModGuid` allows clients without it while preserving the mod author's default when no rule matches
* Conditional consumers now advertise their existing version handshake from clients even when author-default optional, allowing the server to require them reliably without changing protocol 1
* snapshots the effective Conditional requirement per connection so live policy reloads affect only new connection attempts and never disconnect existing peers
* keeps normal compatibility checks for advertised Conditional consumers even when the server allows the consumer to be absent
* extended policy status, reload, validation, dump, watcher lifecycle, diagnostics, README, and project context for mod-requirement policy

# 1.0.5
* cached full server synchronization snapshots per authoritative state revision and administrator class, reusing already serialized and compressed wire data for later initial syncs, complete resyncs, and full authoritative corrections until synchronized state changes
* added Verbose serialization and compression diagnostics with raw/wire sizes, compression ratio, time spent serializing/compressing, and full-snapshot build/reuse reporting
* added Trace per-entry serialized payload sizes plus a once-per-session warning for large synchronized string custom values that are candidates for parsed structured or binary transfer

# 1.0.4
* fixed a Visual Studio CPS `LimitedFunctionality` project-tree error by removing the imported `Thunderstore.targets` file from the SDK default `None` item list while keeping it as an explicit MSBuild import
* fixed the 1.0.4 source build against the existing Unity reference set by removing an unnecessary `Canvas.ForceUpdateCanvases()` call from connection-error layout normalization
* fixed optional client-side CCS consumers remaining in a fail-closed replica state when the connected server does not provide that mod; after successful `PeerInfo`, the instance now returns to local config ownership without raising `InitialSyncCompleted`
* classified version-check failures as a missing handshake, missing protocol metadata, protocol mismatch, invalid version data, or a specific mod-version range mismatch
* changed connection-rejection diagnostics to unconditional error logs so disconnect causes are recorded even when debug logging is disabled
* added the remote client identifier, reported Conditional Config Sync package version, protocol, and handshake timing to version-check logs
* kept received version-handshake state per peer so simultaneous connections cannot overwrite the diagnostics used for another client
* added an optional trailing Conditional Config Sync package version to the compatible protocol 1 handshake without changing the wire protocol version
* sends one bounded structured English disconnect report with a report ID and explicit reason codes before the vanilla version error
* associates pending disconnect reports with one client connection attempt, preserves them across the failed `ZNet` shutdown, and clears them after success, display, a new attempt, or timeout
* appends CCS diagnostics to the existing Valheim error text before Jotunn and ServerSync process it, preserving Jotunn's separate compatibility window
* only augments the connection error when an explicit report belongs to the current CCS rejection, avoiding speculative CCS text for unrelated `ErrorVersion` failures
* normalizes the vanilla connection-error layout one frame later without repeatedly moving the confirmation button
* records malformed version-handshake packages and improves reporting when a required remote mod did not process the shared version RPC

# 1.0.3
* fixed initial handshake buffering so vanilla `PlayerList` and `AdminList` are delivered after `PeerInfo`, preserving `LocalPlayerIsAdminOrHost()` and the initial player list

# 1.0.2
* exposed a structured policy-control availability state so configuration UIs can distinguish a missing compatible server session from missing administrator access
* renamed the public package metadata type from `PluginSelfInfo` to `PluginInfoCCS`
* added public read-only effective synchronization metadata for configuration UIs and diagnostics
* exposed normalized default ownership, effective ownership, policy initialization, hidden state, and effective ownership overrides
* effective ownership falls back to the normalized mod default until policy state is initialized
* added an administrator-authorized API for toggling individual Conditional settings between server and client ownership
* policy changes requested by compatible configuration UIs are persisted as minimal exact-setting rules in SyncPolicy.cfg
* fixed-mode settings and unauthorized clients cannot use the policy toggle API
* compatible servers advertise policy-control support through an optional extension of the existing lock-exemption entry
* no network protocol changes
* fixed stale configuration-manager permissions by failing closed during connection and re-evaluating read-only metadata after initial synchronization
* added a high-priority runtime guard that restores protected BepInEx config values before an unauthorized change notification can be processed
* removed local fallback presence from write authorization; effective ownership, initial sync, admin status, server lock, and explicit unlocked-update opt-in now determine writability
* changed `AllowClientConfigUpdatesWhenUnlocked` to a secure disabled-by-default opt-in for non-admin clients
* hardened server-side client update validation with ready-peer checks, per-entry ownership and permission checks, duplicate/unknown/trailing-data rejection, and all-or-nothing parsing before application
* client updates no longer send authoritative config state; matching legacy state claims remain accepted only as non-authoritative compatibility validation
* stopped forwarding original client packages and now redistribute canonical values and server-computed state to every client, including the initiator
* added rate-limited authoritative correction or full resynchronization after rejected client updates
* added explicit accepted/rejected client-update audit logs with sender and authorization state
* ensured an already registered locking entry is upgraded to protected always-server-controlled state
* stabilized the public core assembly identity at `1.0.0.0` for compatible 1.x releases while retaining current file and informational versions
* renamed the policy reload summary tag from `[Policy]` to `[SyncPolicy]`
* added comprehensive architecture, rationale, compatibility, security, test, and release context in `PROJECT_CONTEXT.md`

# 1.0.1
* renamed PluginInfo class to resolve conflict with BepInEx class with similar name

# 1.0.0

Initial release of Conditional Config Sync, a standalone shared dependency for Valheim mods.

## For players

- Provides synchronization infrastructure for mods that declare Conditional Config Sync as a dependency.
- Adds no gameplay content, items, UI, or standalone configuration of its own.
- Can run alongside Jotunn and mods that use ServerSync without replacing, modifying, or intercepting either library.
- Keeps synchronization fixes centralized, so dependent mods can receive runtime fixes by updating this package.

## For server administrators

- Provides three setting ownership modes: `AlwaysServerControlled`, `Conditional`, and `AlwaysClientControlled`.
- Supports exact-setting and whole-section ownership rules through `ConditionalConfigSync.SyncPolicy.cfg`.
- Supports exact-setting and whole-section visibility rules through `ConditionalConfigSync.HiddenConfigs.cfg`.
- Loads policy during server startup and applies stable file changes at runtime on the Unity main thread.
- Provides a protected locking setting with administrator exemption and non-admin write validation.
- Includes `status`, `policy_reload`, `policy_validate`, and `policy_dump` commands for policy operation and diagnostics.
- Synchronizes regular BepInEx configuration values and runtime custom values with bounded payloads, fragmentation support, and explicit rejection errors.
- Restores local client values and ownership state correctly when policy changes or the server connection ends.

## For mod authors

- Distributed as a standalone BepInEx hard dependency; reference `ConditionalConfigSync.dll` instead of embedding or ILRepacking a private copy.
- Provides familiar `ConfigSync`, `SyncedConfigEntry`, `CustomSyncedValue`, and `VersionCheck` APIs with XML IntelliSense documentation.
- Lets each mod explicitly require a compatible copy on the remote client or server through the documented `ModRequired` option.
- Supports one-call bind-and-register overloads that assign ownership before registration.
- Provides fixed and policy-controlled config modes for shared mechanics, client-local presentation, and administrator-selectable behavior.
- Provides state-like and sequenced custom values, priorities, equality comparers, explicit assignment modes, and `ISerializableParameter` support.
- Uses TOML conversion for regular BepInEx entries and length-prefixed package entries for safer parsing and forward handling.
- Provides lifecycle, policy, lock, connection-reset, rejection, and initial-sync events.
- Supports late registration, automatic resynchronization, and explicit `RequestFullSync()`.
- Isolates failures from individual `SettingChanged` handlers so remaining package entries can still be applied.
- Uses an independent numeric wire protocol and requires an exact client/server protocol match.
- Includes release SHA-256 hashes for both runtime DLL files.

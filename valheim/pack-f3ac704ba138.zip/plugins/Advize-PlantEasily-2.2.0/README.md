![](https://staticdelivery.nexusmods.com/mods/3667/images/2350/2350-1732389890-1212673572.png)

| [Description](#description) | [Keybinds](#default-keybinds) | [Installing](#installing) | [Compatibility](#compatibility) | [Contact Author](#contact-author) | [Other Info](#config-and-other-info) | [Config](#config) | [Source](#source) | [Screenshots](#screenshots) |
|---|---|---|---|---|---|---|---|---|

## Description
This is a QoL mod that simplifies the planting aspect of farming, and fixes a lot of common frustrations with it. It allows you to quickly and easily plant beautiful and evenly spaced fields of crops without ever worrying about wasting a precious seed. Once those crops mature, you can optionally harvest them in bulk, and/or replant automatically. Its feature-set also supports berry bushes, flowers, and mushrooms from Plant Everything.

Whether you want to plant one crop at a time, or several at once to save time, this mod can do that. You can plant a single crop, a single row, a single column, or any number of rows and columns at once; the size of which can be changed easily in real-time using keybinds (configurable).

In addition to planting in bulk, this mod will optionally allow you to harvest in bulk (configurable). Works for all pickables as well as beehives.

If you don't want your fields to look too uniform, this mod will by default put a random rotation on your crops once placed (configurable). It also supports random positional and rotational scatter.

If you don't want to plant a crop too close to another, worry not. This mod by default will highlight your invalid crops in red before they are placed, and also by default will prevent you from planting anywhere a crop cannot grow (configurable). Causes include wrong biome, uncultivated ground, no space, no sunlight, lack of resources, too hot, too cold, and no attach piece (Ashvines).

Tired of replanting the same fields over and over again? Enable [Harvesting]ReplantOnHarvest in the mod's configuration file or via configurable keybind. When enabled, crops will automatically replant themselves upon being picked, provided the player has enough seeds. You can change what is planted in a crop's place by selecting your desired crop in the cultivator build tab before putting your cultivator away and harvesting a plant.

And last but definitely not least, this mod provides grid snapping (configurable). Snap individual crops to a single crop, to an existing grid of crops, or snap a new grid of crops onto either a single crop or an existing grid of crops. Alternative placement options have been added to the cultivator to support free 360 degree rotation when snapping to a single piece (see Default Keybinds).

`Note: If a piece is not snapping where you'd expect, try rotating the piece.`

## Support Me!

Thank you to everyone who has used my mods at any time during early access. It was your collective passion, not mine alone, that fueled me these 5 long years.

If you would like to keep supporting the development and maintenance of my mods you can do this through the paypal image link below.

Looking for a Valheim server? I have partnered with SurvivalServers.com. For a limited time you can get 25% off with the code `VALHEIM25`! Order through my affiliate link by clicking on the image below and I will receive a portion of the proceeds.

<p align="center">
<a href="https://www.paypal.com/donate/?hosted_button_id=PKLGAT5ZBB2YE"><img src="https://raw.githubusercontent.com/AdvizeGH/Advize_ValheimMods/refs/heads/main/SharedImages/Paypal.png?raw=true"></a>
<a href="https://www.survivalservers.com/r/advize/valheim"><img src="https://raw.githubusercontent.com/AdvizeGH/Advize_ValheimMods/refs/heads/main/SharedImages/HostingAd.png?raw=true"></a>
</p>

## Default Keybinds

These keybinds are not checked in a standard update tick, they will only work while the cultivator is equipped and an applicable piece is selected. All keybinds are configurable.

Right CTRL + Arrow Keys increases/decreases rows and columns.
<br>
Left Bumper + D-Pad increases/decreases rows and columns.

Left Shift + Use Key to bulk harvest (when enabled).
<br>
Left Bumper + Use Key to bulk harvest (when enabled).

Pressing your vanilla alternative placement key allows free 360 rotation when snapping to a single piece.
<br>
Hold Left Shift while planting and snapping.
<br>
Hold Left Bumper and press Right Stick to toggle.

F6 toggles crop replant on harvest, F8 toggles all mod features, F10 toggles grid snapping features.
<br>

The three available toggle keys support keyboard combinations (e.g. Left Ctrl + F8).

## Installing

### Manual Install

This is a client-side only mod. Do not install it on a dedicated server.

Extract the Advize_PlantEasily.dll file into the BepInEx/plugins folder.
Directory structure should look like this:
```
BepInEx ->
    plugins ->
        Advize_PlantEasily.dll
```

## Compatibility
Here you'll find info about known mod conflicts and possible solutions.

At present, this mod is incompatible with any of the following:

### FarmGrid

### MassFarming

### Farming

## Contact Author
You can reach me on NexusMods to provide bug reports or feedback https://www.nexusmods.com/valheim/mods/2350

For further mod or mod dev support, I can be found at the following Discord server:

[![](https://i.imgur.com/HZMpQip.png)](https://discord.gg/89bBsvK5KC)

## Config and Other Info:
Mod is highly configurable, a config file will be generated after first loading the mod and can be found in BepInEx/config/advize.PlantEasily.cfg

The config can be edited out of game with a text editor, or modified in game using the Configuration Manager mod.

## Config
### Default Config File:
```
Please see Nexus mod page for the default configuration.
```
## Source
Github Repo: [Advize_ValheimMods](https://github.com/AdvizeGH/Advize_ValheimMods)

## Screenshots
![](https://staticdelivery.nexusmods.com/mods/3667/images/2350/2350-1732390619-2106143936.png)

![](https://staticdelivery.nexusmods.com/mods/3667/images/2350/2350-1680396207-678103137.png)

![](https://staticdelivery.nexusmods.com/mods/3667/images/2350/2350-1773518288-239449752.png)

![](https://staticdelivery.nexusmods.com/mods/3667/images/2350/2350-1680393071-2012614102.png)

![](https://staticdelivery.nexusmods.com/mods/3667/images/2350/2350-1680393102-1729624824.png)

# Candles Forever

### The new candles are cool but not perfect.  Make them better by never letting them burn out.

By TastyChickenLegs and TCL-MODS

- Never let the candles burn out
- Choose to keep them tall or let them burn naturally
- Chose to ignore rain and keep them lit

[Chat with me on Discord](https://discord.gg/PQMXbUS6FH)




### Configuration:

The config file is located in "<GameDirectory>\Bepinex\config" (You need to start the game at least once, with the mod installed to create the config file).



### Installation: (manual)  


Extract DLL from zip file into "<GameDirectory>\Bepinex\plugins"  or use your favorite mod manager
Start the game.

### Version Information

1.0.4

- udpated to Valehim Version 1.0

1.0.3

updated to newest version of the game.  No other changes.


1.0.2
update to fix multiplayer problem.  ServerSync updated along with most recent gamefiles


1.0.1

- Fixed the naming of the config file.

1.0.0

- initial release

##	Now for the shameless plug

> ### My Other Mods:
>>* [Drop More Loot](https://valheim.thunderstore.io/package/TastyChickenLegs/DropMoreLoot/)
>>* [Automatic Fermenters](https://valheim.thunderstore.io/package/TastyChickenLegs/AutomaticFermenters/)
>>* [No Smoke Stay Lit](https://valheim.thunderstore.io/package/TastyChickenLegs/NoSmokeStayLit/)
>>* [No Smoke Simplified](https://valheim.thunderstore.io/package/TastyChickenLegs/NoSmokeSimplified/)
>>* [Honey Please](https://valheim.thunderstore.io/package/TastyChickenLegs/HoneyPlease/)
>>* [Automatic Fuel](https://valheim.thunderstore.io/package/TastyChickenLegs/AutomaticFuel/)
>>* [Forsaken Powers Plus](https://valheim.thunderstore.io/package/TastyChickenLegs/ForsakenPowersPlus/)
>>* [Recycle Plus](https://valheim.thunderstore.io/package/TastyChickenLegs/RecyclePlus/)
>>* [Blast Furnace Takes All](https://valheim.thunderstore.io/package/TastyChickenLegs/BlastFurnaceTakesAll/)
>>* [Timed Torches Stay Lit](https://valheim.thunderstore.io/package/TastyChickenLegs/TimedTorchesStayLit/)
>>* [Automatic Fermenters](https://valheim.thunderstore.io/package/TastyChickenLegs/AutomaticFermenters/)

# Changelog

## 1.0.1
- Fixed settings not syncing reliably when joining a server. Clients now also ask the server for settings after connecting, and go back to local settings when they leave.

## 1.0.0
- Initial release: wood and stone portals each have their own settings for whether they can be built, extra build cost, and their portal style (`Default` or `Fueled`, with fuel modes `UsesPerFuel`, `TimePerFuel` or `UntilSunriseOrSunset` and a configurable fuel item), and customizable fuel text. Server-synced settings.

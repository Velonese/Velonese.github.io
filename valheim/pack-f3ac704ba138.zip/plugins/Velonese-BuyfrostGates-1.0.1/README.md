# BuyfrostGates

Portals are a late-game luxury, and they cost something to run.

## Features

**Choose which portals can be built**
- Wood and stone portals can each be shown or hidden in the hammer build menu.
- By default the wood portal is hidden and the stone portal is available.
- Portals that already exist keep working.
- Admins can still place hidden portals in debug mode with no-cost building.

**Extra build cost**
- Each portal type can have extra items added to its normal build cost, e.g. `BlackCore:2, Eitr:10`.
- Choose whether the extra items are refunded when the portal is deconstructed.

**Fuel per teleport**
- Wood and stone portals each have their own portal style and fuel settings.
- By default a stone portal needs fuel (1 Surtling Core = 20 teleports), and a wood portal doesn't.
- To refuel, look at the portal and use the fuel item from your hotbar.
- With `AutoRefuel` on, walking into an empty portal takes the fuel from your inventory instead.
- With `UsesPerFuel`, each teleport uses one charge from the portal you walk into. The destination portal is not charged.
- With `TimePerFuel`, the portal instead stay active for a set time per refill, with free teleports until it runs out.
- With `UntilSunriseOrSunset`, the portal stays active until the next sunrise or sunset.
- Hovering over the portal shows how many teleports or how much time is left.
- Blocked teleports (non-teleportable items, the No Portals world modifier, etc.) use no fuel.

## Configuration

`BepInEx/config/velonese.buyfrostgates.cfg`, or press F1 in game with BepInEx ConfigurationManager installed.

The `[Wood Portal]` and `[Stone Portal]` sections have the same settings:

| Setting | Wood default | Stone default | Description |
|---|---|---|---|
| `Buildable` | `false` | `true` | Show the portal in the hammer build menu. |
| `ExtraBuildCost` | *(empty)* | *(empty)* | Items added to the build cost, e.g. `BlackCore:2, Eitr:10`. |
| `RefundExtraBuildCost` | `true` | `true` | Deconstructing gives back the extra items. When off, only the vanilla cost is refunded. |
| `PortalStyle` | `Default` | `Fueled` | `Default` (vanilla) or `Fueled`. |
| `FuelMode` | `UsesPerFuel` | `UsesPerFuel` | How a `Fueled` portal uses fuel (see Fuel modes below). |
| `FuelItem` | `Resin` | `SurtlingCore` | Prefab name of the fuel item. Any item works (e.g. `BlackCore`, `Eitr`, `Coins`). |
| `AutoRefuel` | `false` | `false` | Walking into an empty portal uses fuel items from your inventory automatically. |
| `FuelItemsPerRefill` | `5` | `1` | Items used per refill. |
| `TeleportsPerRefill` | `10` | `20` | `UsesPerFuel` only: teleports gained per refill. |
| `SecondsPerRefill` | `600` | `600` | `TimePerFuel` only: seconds the portal stays active per refill. |

### Portal styles

- `Default`: a normal vanilla portal. No fuel, and `FuelMode` and the fuel settings are ignored.
- `Fueled`: the portal needs fuel to teleport, in the way set by `FuelMode`.

### Fuel modes

- `UsesPerFuel`: use the fuel item on the portal to add teleport charges. Each teleport uses one charge.
- `TimePerFuel`: use the fuel item on the portal to keep it active for a while. Teleports are free until the time runs out, then the portal goes dark until it is refuelled. Refuelling an active portal adds to the time left. The timer runs on world time, so it keeps counting down while nobody is nearby.
- `UntilSunriseOrSunset`: use the fuel item on the portal to keep it active until the next sunrise or sunset. Teleports are free until then. Refuelling an active portal extends it to the following sunrise or sunset. Sleeping through the night skips to morning, so a portal fuelled until sunrise runs out.

### Text

Each portal type also has a `[Wood Portal Text]` / `[Stone Portal Text]` section, so all the fuel text shown on hover and in
messages can be changed per portal type. Templates use placeholders, which each setting's description lists:

| Setting | Default |
|---|---|
| `HoverFuel` | `Fuel: {left}` |
| `HoverNoFuel` | `<color=red>No fuel</color> - {hint}` |
| `NoFuelMessage` | `Portal has no fuel - {hint}` |
| `RefuelledMessage` | `Used {amount}x {item} - portal fuel: {left}` |
| `NotEnoughFuelMessage` | `Refuelling needs {amount}x {item}` |
| `HintHotbar` | `use {amount}x {item} from your hotbar {refill}` |
| `HintAutoRefuel` | `walk in with {amount}x {item} to refuel {refill}` |
| `RefillUses` / `RefillTime` / `RefillSun` | `for {count} teleports` / `for {time}` / `until the next sunrise or sunset` |
| `LeftUses` / `LeftUsesOne` / `LeftTime` / `LeftSun` | `{count} teleports left` / `1 teleport left` / `{time} left` / `until {sunchange} ({time})` |
| `Sunrise` / `Sunset` | `sunrise` / `sunset` |

Leave a hover or message setting empty to hide it. Unity rich text such as `<color=red>` works.

## Multiplayer

Install on the server and on every player. The server's settings are sent to players when they join,
and again when the server's config file is edited while it is running.
A player without the mod can still join, but won't have the fuel rules applied on their side.

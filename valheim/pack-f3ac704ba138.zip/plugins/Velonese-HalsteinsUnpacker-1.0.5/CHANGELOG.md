# Changelog

## 1.0.5
- Fixed a loop where the client kept asking for the same config files after every restart, ending in an "incompatible version" kick. Configs the pack already installed are no longer re-downloaded just because a mod rewrote them.

## 1.0.4
- Fixed the server rejecting a good modpack manifest ("it has no archive"): the manifest is now read with a more reliable JSON reader.

## 1.0.3
- The modpack manifest types are now public.

## 1.0.2
- The log now shows what the server received when a modpack manifest has no archive, to help find why.

## 1.0.1
- Fixed the modpack offer not reaching every joining player reliably, and players being offered the pack more than once.

## 1.0.0
- Initial release: servers offer a modpack (a manifest plus one zip) over https. Joining players download it when
  they are missing or behind on plugins or configs, then restart and rejoin. Plugins are only ever upgraded.

# Changelog

## 1.0.0
- Initial release: placing a pile or stack with the hammer uses no stamina. The list of pieces is configurable.

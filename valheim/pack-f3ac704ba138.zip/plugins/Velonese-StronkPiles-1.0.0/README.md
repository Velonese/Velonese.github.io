# StronkPiles

Stack your resources without running out of breath.

## Features

- Placing any pile or stack from the hammer build menu uses no stamina, such as the wood, stone, flint and coal piles
  and the metal bar stacks. The items the pile costs are unchanged.
- The list of pieces is set in the config file, so you can add or remove pieces.
- You can place piles even when your stamina bar is empty.
- Removing and repairing pieces, and placing everything else, cost stamina as normal.

## Configuration

`BepInEx/config/velonese.stronkpiles.cfg`, or press F1 in game with BepInEx ConfigurationManager installed.

| Setting | Description |
|---|---|
| `Pieces` | Prefab names of the pieces that use no stamina to place, separated by commas. |

The default is all standard storage piles and stacks:

`wood_stack`, `wood_fine_stack`, `wood_core_stack`, `wood_yggdrasil_stack`, `blackwood_stack`, `wood_frost_stack`,
`stone_pile`, `flint_pile`, `coal_pile`, `blackmarble_pile`, `grausten_pile`, `bone_stack`, `skull_pile`,
`bar_tin_stack`, `bar_copper_stack`, `bar_bronze_stack`, `bar_iron_stack`, `bar_silver_stack`,
`bar_blackmetal_stack`, `bar_flametal_stack`, `bar_gold_stack`

Any buildable piece can be added, not just piles. Changes made through ConfigurationManager apply straight away.
Names that are not a buildable piece are ignored, with a warning in the BepInEx log when the world loads.

## Multiplayer

Only the players who want free pile placement need the mod. The server and other players do not.

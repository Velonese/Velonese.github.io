#
# v1.4.2
- updated for valheim 1.0 deepnorth
#
# v1.4.1
- updated for the latest valheim build (221.10)
#
# v1.4.0
- fixed some minor loading issue.
#
# v1.3.9
- updated for the latest bepinex build (5.4.2333).
- updated for the latest valheim build (221.4) call to arms update.
- updatd unity project with the latest game rip.
- disabled DOF when underwater which causes unity warning.
#
# v1.3.8
- updated serversync.
#
# v1.3.7
- added a new bubble vfx when diving underwater with oxygenbubble or atlanteancrown is equipped (huge thanks to krumpac for the vfx).
- added 5 statuseffect with different duration (to be use on krumpacs mods).
#
# v1.3.6
- fixed encumbered bug, stamina will not regen anymore when player is encumbered and also swim speed is super slow when encumbered.
#
# v1.3.5
- updated for the latest valheim build (219.13) bog witch
#
# v1.3.4
- minor code fixes
#
# v1.3.3
- updated for the latest valheim build (218.15 ashlands)
#
# v1.3.2
- excluded hotkeys from being locked and sync.
- updated serversync.
#
# v1.3.1
- updated to the latest valheim build (217.38)
#
# v1.3.0
- updated to the latest valheim build (217.28)
- updated serversync and dependencies
- updated manifests bepinex dependency string
- put localization example to a zip package to avoid unnecessary duplicates
#
# v1.2.9
- removed server enforcement.
- added configuration for swim stamina drain min/max skill.
#
# v1.2.8
- fixed multiplayer version check issues
#
# v1.2.7
- updated to the latest valheim build (217.22)
#
# v1.2.6
- fixed swim sprinting bug.
- added german and spanish translations (thanks to @BLUBBSON and @Azathoth)
#
# v1.2.5
- added config for recipe.
- added config option to disable recipe.
- added translations.
- added russian translations (credits to nexusmod user @ashik83 for providing the translation.)
#
# v1.2.4
- removed item manager.
- added compatibility fixed to krumpacs new water shader.
#
# v1.2.3
- updated to the latest valheim build (217.14) hilders request.
#
# v1.2.2
- fixed an NRE when you die in the middle of the ocean
#
# v1.2.1
- added compatibility support to krumpacs custom waters (you can now dive on his dungeons)
- supports any custom water that uses water volume scripts.
#
# v1.2.0
- fixed fog effect bug with some areas like shores ands swamps.
#
# v1.1.9
- updated to the latest valheim build (216.9)
#
# v1.1.8
- added a new magical crown that you can use to dive longer underwater, it gives the wearers ability to breath underwater or rather a status effect that lets you recover your stamina while underwater xD (as requested in O+ dc)
#
# v1.1.7
- added configurable sprint hotkey (you can now sprint while swimming or diving, sprinting speed is scaled by your swim skill level.)
- you can no longer stay underwater for too long, your stamina will be slowly depleted while underwater.
- some minor bug fixes
#
# v1.1.4
- remove incompatibility tag with rune magic
#
# v1.1.3
- optimized code and updated serversync
- added incompatibility to better diving and rune magic mod to avoid conflict with patching the water surface
#
# v1.1.2
- added version checks
- updated to latest valheim assemblies
#
# v1.1.1
- fixed DOF bug, DOF WILL NO LONGER DEACTIVATES IF YOU HAVE IT ON by default
- changed Fog Effect activation, it will no longer activates in foggy areas like the swamps.
#
# v1.1.0
- added underwater brightness settings.
- added underwater fog density settings.
- added underwater min/max fog density settings.(as requested)
#
# v1.0.9
- added possible fix for dof being forced to turnoff when it is being use as default. (damn my eyes hurt its hard to tell the difference with my test machine)
#
# v1.0.8
- added config option for dive and ascend key
- added joystick compatibility tested with an xbox360 controller (forgot to add this with the last update)
#
# v1.0.7
- fixed errors on dedicated servers running on linux
#
# v1.0.6
- fixed bug that makes your char float in the air after coming out of diving.
- added DOF effect when underwater.
#
# v1.0.5
- Added Config Watcher
- Added new Diving Mechanic
#
# v1.0.1
- added max swim speed configuration
- fix stamina bug when mod is off
#
# v1.0.0 
- first release
#
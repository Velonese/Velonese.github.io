># <b># VikingsDoSwim</b>

A simple mod that lets you configure Max Swim Speed at max swim skill level. Scales your swim speed, stamina regen and stamina consumption to your swim skill level. Adds a new diving mechanic that lets you swim underwater.

<br/>

>## ## Installation (manual)

- extract `VikingsDoSwim.dll` file to your `BepInEx\Plugins` folder.

<br/>

>## ## Features

- Configurable exp multiplier for swim skill.
- Idle stamina regen base on swim skill.
- Swim speed scaled by swim level.
- Configurable Max Swim Speed at Max Skill Level.
- Diving mechanic that lets you swim underwater.
- Uses ServerSync to sync configs from servers to clients.
- Uses built in config watcher.
- Joystick compatible tested with an xbox360 controller.
- Configurable underwater brightness.
- Configurable underwater fog density.
- Configurable swim stamina drain min/max skill.
- Configurable through config file or [configuration manager](https://valheim.thunderstore.io/package/Azumatt/Official_BepInEx_ConfigurationManager/)

<br/>

<details>
<summary><b>How To Dive?</b> (<i>click to expand</i>)</summary>

- While swimming in the water press crouch/sneak key ( left control ) together with forward direction key ( W ) then use mouse to navigate to the direction you want to go.
- ( W + Left Control ) + Mouse.
- While holding W + Left Control you can dive down or up using mouse to navigate.
- If you release Left Control you can swim normally using direction keys ( W A S D ) but you can't dive down or up.
- Diving also uses your stamina so better prepare foods with lots of stamina or stamina potion.
- If you run out of stamina while underwater you'll take damage normally until your hp goes down and you'll die.
- If you run out of stamina or you just want to go back up quickly you can press jump key ( Space ).
- While idle in the water your stamina will naturally regen.

<br/>
</details>
<br/>

>## ## Recommended Mod:
- If you want to use your equipment underwater or while in the water, use my [WieldEquipmentWhileSwimming](https://valheim.thunderstore.io/package/blacks7ar/WieldEquipmentWhileSwimming/) mod.. It supports all kinds of equipments vanilla or modded.
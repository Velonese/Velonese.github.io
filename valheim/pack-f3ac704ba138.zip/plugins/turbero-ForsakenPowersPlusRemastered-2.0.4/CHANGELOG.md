### CHANGELOG

## 2.0.4

* Recompiled for compatibility with 1.0
* ServerSync upgrade
* Fixed issue that removed current active boss power when clicking boss power button again. 

## 2.0.3

* Added support for non-vanilla boss powers created in other mods. Now the rotation after last vanilla power will continue to the learnt non-vanilla powers without errors.

## 2.0.2

* Added new option to enablePassiveMode option called "OnMultiple" to allow using multiple passive power buffs at once. To have just one maximum, use "On" value.
* Fixed little mess with messagePowerSelected config option

## 2.0.1

* Added config option to allow activating all available player powers at once

## 2.0.0

New remastered release. Summary of features:
* Toggle your learnt powers without going back to spawn stones
* Reset your power immediately to use a new one (if activated in config)
* Change power buff cooldown timer
* Change power buff duration timer
* Customize messages to your own language in the config file

Others:
* ServerSync support
* Compiled with latest game version Call to Arms 0.221.4

## 1.4.1

Deprecated version https://thunderstore.io/c/valheim/p/TastyChickenLegs/ForsakenPowersPlus/
# HalsteinsUnpacker

Players who join your server get its modpack installed for them. No more "which mods do I need?".

## How it works for players

1. Join the server as normal.
2. The first time, HalsteinsUnpacker asks whether you trust the server to install mods. Mods can run any code on your computer,
   so only say yes to servers you trust.
3. If you're missing mods, or yours are out of date, you're taken back to the main menu with a list of what will be
   downloaded. Accept it, and HalsteinsUnpacker downloads and checks the files.
4. Restart Valheim. It installs the files before any mod loads, then you rejoin the server.

HalsteinsUnpacker only touches the files in the server's pack. Mods you added yourself are left alone, and nothing is deleted.
Plugins are only ever upgraded: if you already have a newer version than the server's pack, you keep yours and
HalsteinsUnpacker tells you. The first time the pack overwrites one of your config files, your copy is saved in
`BepInEx/config/.halsteinsunpacker-backup/`.

You need BepInEx and HalsteinsUnpacker installed before you join. After that, HalsteinsUnpacker keeps you in sync, including updating
itself.

## Setting up a server

1. Make a folder laid out like `BepInEx/`, containing only what players should get:

   ```
   MyPack/
     plugins/Author-SomeMod-1.2.3/...
     config/author.somemod.cfg      <- only the configs you want to push to players
   ```

2. Build the pack with the script from this mod's source (needs PowerShell and any BepInEx install for Mono.Cecil):

   ```
   ./tools/Build-Manifest.ps1 -Source C:\Packs\MyPack -PackName "My Server" -PackVersion 1.0.0
   ```

   It writes `manifest.json` and `pack-<hash>.zip` to `C:\Packs\MyPack-publish\`.
3. Upload both files to the same folder on any https static host (GitHub Pages, a GitHub release, S3,
   Cloudflare R2, your own web server).
4. Install HalsteinsUnpacker on the server and set `ManifestUrl` in
   `BepInEx/config/velonese.halsteinsunpacker.cfg` to the manifest's https URL.

To update the pack, change the folder, re-run the script, and upload both new files. The server picks up the new
manifest within `RefreshMinutes`.

Players only fetch the small manifest to check whether they're up to date. They download the zip only when something
is missing or newer, and unpack just the files they need.

## Configuration

`BepInEx/config/velonese.halsteinsunpacker.cfg`

| Section | Setting | Description |
|---|---|---|
| Server | `ManifestUrl` | https URL of the pack's `manifest.json`. Empty means no pack is offered. |
| Server | `RequireSync` | Disconnect players who don't have HalsteinsUnpacker or aren't up to date. Off by default. |
| Server | `SyncTimeoutSeconds` | With `RequireSync`, how long a player has to confirm they're up to date. |
| Server | `RefreshMinutes` | How often the server re-reads the manifest. |
| Client | `Enabled` | Offer to install the modpack of servers you join. |
| Client | `TrustedPacks` | Servers you've allowed to install mods. Delete an entry to be asked again. |
| Client | `MaxFileSizeMB` / `MaxTotalSizeMB` | Largest single unpacked file, and largest modpack zip. |

## Security

- The pack must be served over https. The server tells players the manifest's SHA-256 hash; the zip and every file
  unpacked from it are checked against their hashes in the manifest before anything is installed.
- Files can only be written inside `BepInEx/plugins` and `BepInEx/config`. BepInEx itself and HalsteinsUnpacker's
  preloader can't be changed by a pack. Zip entries the manifest doesn't list are ignored.
- Players are asked before a new server or manifest URL can install anything.

## Notes

- Works with r2modman and Thunderstore Mod Manager profiles: restart Valheim from your mod manager as usual.

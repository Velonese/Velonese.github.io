# Changelog

## 1.0.0
- Initial release: each kill without a trophy raises that creature's trophy chance by a percentage of its current chance. The chance resets when a trophy drops. Counts are kept per player by the server.
- Trophies can be sold to the Bog Witch, with a configurable price for each trophy.

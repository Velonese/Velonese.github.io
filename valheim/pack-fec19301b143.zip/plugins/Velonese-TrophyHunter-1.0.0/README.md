# TrophyHunter

Bad luck protection for trophies.

## Features

- Each time you kill a creature and it does not drop its trophy, the trophy chance for that creature goes up by 25%
  of its current chance. A 10% chance becomes 12.5%, then 15.6%, and so on.
- When the trophy drops, the chance goes back to normal.
- Each type of creature is counted separately for each player, and the counts are saved by the server.
- Only kills where a player lands the final blow count.
- Bosses are not affected, and neither is any trophy that always drops.

- Trophies can be sold to the Bog Witch for coins. Other traders still refuse them. Forsaken and always-drop trophies cannot be sold by default.

## Configuration

`BepInEx/config/velonese.trophyhunter.cfg`, or press F1 in game with BepInEx ConfigurationManager installed.

| Setting | Description |
|---|---|
| `Enabled` | Turn the rising chance on or off. |
| `GrowthPercent` | How much the chance rises per kill without a trophy, as a percent of the current chance. Default 25. |
| `MaxChancePercent` | The chance never rises above this percent. Default 100. |
| `ExcludedCreatures` | Prefab names of creatures that keep the normal chance, separated by commas. |
| `Selling` > `Enabled` | Let trophies be sold to the traders listed in `Buyers`. |
| `Selling` > `Buyers` | Traders that buy trophies, separated by commas. Default `bogwitch`. A trader matches if its name contains the text. |
| `Prices` | One entry per trophy, added to the config file the first time the game loads. Coins paid; 0 means it cannot be sold. |

## Selling trophies

Each player needs the mod to see the prices and sell, but the server does not need it for this. Prices run from 3 coins in the
Meadows to 200-400 coins for late-game trophies. Trophies that always drop (Forsaken and named creatures) default to 0, so
they cannot be sold. Any trophy the mod does not know about defaults to 50 coins. Edit the prices in the config file after
the game has loaded once.

## Multiplayer

Install the mod on the server and on every player who wants the effect.

- The server keeps each player's kill counts for the world, in `BepInEx/config/TrophyHunter/<world>.txt` on the server.
  Players are identified by their platform ID, so counts survive reconnecting. Counts belong to the world, not the character.
- Kills count even when another player's game is running the creature. The game running the creature rolls the drop
  using the killer's counts and reports the result to the server.
- If the server does not have the mod, drops are left as vanilla.
- The server trusts what players report, so this is meant for private servers.
- In a hosted or single-player game, the host acts as the server and is saved as `host`.

## Notes

Valheim normally smooths out low trophy chances with a hidden counter. For creatures this mod affects, the mod's own
chance is used instead.
